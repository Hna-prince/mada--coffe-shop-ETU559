<?php
class RewritingPerso extends CI_Controller{

    public function __construct()   {    
        parent::__construct();
    }

    public function index(){
        $this->accueil();
    }

    public function completerUrl($code, $eventuelGet){
        $urlComplete='';
        /*Code--------------
        100 = acceuil
        230 = listvariete
        412 = detailVariete
        777 =listArtCafe
        786 = gallery
        */
        
        
        $urlAccueil         ="accueil-MADA-COFFEE-SHOP-cafe-06042018.html";
        $urlListVariete     ='variete/listes-differents-specialites-cafe-MADA-COFFEE-SHOP-06042018.html';
        $urlDetailVariete   ='variete/coffee-detail-description-cafe-MADA-COFFEE-SHOP-' . $eventuelGet . '-06042018.html';
        $urlListArtCafe     ='art/listes-oeuvres-barista-cafe-MADA-COFFEE-SHOP-06042018.html';
        $urlGallery         ='gallery-cafe-MADA-COFFEE-SHOP-06042018.html';

        
        //$urlListVariete     ='catalogue/(variete)/(:any)-MADA-COFFEE-SHOP-06042018.html';
                switch($code){
    
                    case 100 :  $urlComplete=$urlAccueil ;
                                break;
                    case 230:  $urlComplete=$urlListVariete;
                                break;
                    case 412 :  $urlComplete=$urlDetailVariete;
                                break;
                    case 777 :  $urlComplete=$urlListArtCafe;
                                break;
                    case 786 :  $urlComplete=$urlGallery ;
                                break;
                    default  : $urlComplete="accueil-MADA-COFFEE-SHOP-cafe-06042018.html";
                }

        redirect($urlComplete,'refresh');
    }

   
}