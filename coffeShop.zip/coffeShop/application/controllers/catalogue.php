<?php
class Catalogue extends CI_Controller{

    public function __construct()   {    
        parent::__construct();
    }

    public function index(){
        $this->ListVariete();
    }

    public function ListVariete(){
        
       $this->load->model('variete_model','variete');
       $data["varieteList"]     = $this->variete->read('*', array(), null, null);
       $data["contents"]        = "pages/variete/listVariete";
       $data["title"]           ="pages/variete/title";
       $data["intro"]           ="pages/variete/intro";
       $data["titleFacultatif"] =" ";
       $this->load->view('templates/template', $data);
    }

    public function DetailVariete($idVariete){
        
        $this->load->model('variete_model','variete');
        $condition["id"]=$idVariete;
        $data["variete"]     = $this->variete->read('*', $condition, null, null)[0];
        $data["contents"]        = "pages/detailVariete/detailVariete";
        $data["title"]           ="pages/detailVariete/title";
        $data["intro"]           ="pages/detailVariete/intro";
        $data["titleFacultatif"] =   $data["variete"]->nom;
        $this->load->view('templates/template', $data);
     }

     public function listArt(){
        
       $this->load->model('artCafe_model','artCafe');
       $data["artCafeList"]     = $this->artCafe->read('*', array(), null, null);
       $data["contents"]        = "pages/artCafe/listArtCafe";
       $data["title"]           ="pages/artCafe/title";
       $data["intro"]           ="pages/artCafe/intro";
       $data["titleFacultatif"] =" ";
       $this->load->view('templates/template', $data);
    }


}

    ?>