<?php
class About extends CI_Controller{

    public function __construct()   {    
        parent::__construct();
    }

    public function index(){
        $this->accueil();
    }

    public function accueil(){
        $data["contents"]        = "pages/accueil/accueil";
        $data["title"]           ="pages/accueil/title";
        $data["intro"]           ="pages/accueil/intro";
        $data["titleFacultatif"] =" ";
        $this->load->view('templates/template', $data);
    }

    public function gallery(){
        $data["contents"]        = "pages/gallery/gallery";
        $data["title"]           ="pages/gallery/title";
        $data["intro"]           ="pages/gallery/intro";
        $data["titleFacultatif"] =" ";
        $this->load->view('templates/template', $data);
    }
}