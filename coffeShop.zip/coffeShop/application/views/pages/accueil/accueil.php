
<div class="container">
  <div class="row">
    <div class="holder_content1">
      <section class="group4">
        <h3>Mada Coffee shop vous permet d'experimenter</h3>
        <article>
          <h4>06.04.2018 - Differents type de cafés <span>Mada coffee shop est un concept franchisé de café, decouvrez de <strong> nouveaux saveurs </strong> et concepts sur les cafes. Etant Nouveau ou expert dans la degustation des varietes de <strong>cafe </strong>. Mada Coffe shop va donner du sensation a vos <strong> papilles </strong>, et emerveiller vos <strong>  yeux </strong>, alors preparez vous!  En plus d'un bon café,Mada coffee shop vous offre une atmosphère détendue, casual et surtout flexible. Nous vous accueillons les bras grand ouvert avec notre horaire flexible.venez comme vous êtes pour faire ce que vous voulez. Nous vous mettons à disposition notre barista qui personnalisera vos café et s'adaptera à vos envies. Et tout cela avec le sourire.  </span></h4>
        </article>
      </section>
    </div>
    <!--end holder-->
  </div>
</div>




<div class="container">
    <div class="row">
      <div class="fourcol">
        <section class="group4">
          <h5>Interieur</h5>
          <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/house/bar-cafe-interieur-mada-coffe-shop.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/house/bar-cafe-interieur-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/house/bar-cafe-interieur-mada-coffe-shop.jpg"); ?>" width="215" height="137" ></a>  
        </section>
      </div>
    
      <div class="fourcol ">
      <section class="group4">
        <h5>>></h5>
        <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/house/interieur-mada-coffe-shop.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/house/interieur-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/house/interieur-mada-coffe-shop.jpg"); ?>" width="215" height="137" ></a> 
       </section>
    </div>

      <div class="fourcol last">
          <section class="group4">
            
            <h5> >> </h5>
            <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/house/table-materiel-mise-en-oeuvre-barista.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/house/table-materiel-mise-en-oeuvre-barista.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/house/table-materiel-mise-en-oeuvre-barista.jpg"); ?>" width="215" height="137" alt=""></a> 
       
      </div>

      
    

    </div>
</div>

/*2 ----------------------------------------*/
<div class="container">
  <div class="row">
    <div class="holder_content1">
      <section class="group4">
        <h3>Nous fabriquons nous memes nos cafes</h3>
        <article>
          <h4>06.04.2018 - Qui vous êtes? 9a vous tente? <span>Admirez et savourez les cafés que Mada coffee shop vous offre. Savez- vous que nous nous occupons nous même du café depuis la torrefaction jusqu'à ce café que vous buvez de votre tasse. Nous tenons particulièrement à satisfaire vos attentes selon vos <strong>goûts, vos sentiments</strong>, le café qui vous identifiera. Alors venez découvrir qui vous êtes à <strong>Mada Coffee shop</strong>.</span></h4>
        </article>
      </section>
    </div>


    <div class="fourcol">
      <section class="group4">
        <h5>Torrefaction</h5>
        <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/etape/torrefaction-cafe-mada-coffe-shop"); ?>" src="<?php echo base_url("assets/images/accueil/etape/torrefaction-cafe-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/etape/torrefaction-cafe-mada-coffe-shop"); ?>" width="215" height="137"></a> 
        
       </section>
    </div>
	
    <div class="fourcol">
        <section class="group4">
          
          <h5> Mouture </h5>
          <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/etape/mouture-moulin-a-cafe-mada-coffe-shop"); ?>" src="<?php echo base_url("assets/images/accueil/etape/mouture-moulin-a-cafe-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/etape/mouture-moulin-a-cafe-mada-coffe-shop"); ?>" width="215" height="137"></a> 
        
       </section>
    </div>

    <div class="fourcol last">
        <section class="group4">
          
          <h5> >> </h5>
          <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/etape/machine-cafe-mada-coffe-shop"); ?>" src="<?php echo base_url("assets/images/accueil/etape/machine-cafe-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/etape/machine-cafe-mada-coffe-shop"); ?>" width="215" height="137" ></a> 
        
       </section>
    </div>
    <!--end holder-->
  </div>
</div>


/*3----------------------------------------*/
<div class="container">
  <div class="row">
    <div class="holder_content1">
      <section class="group4">
        <h3>Vous n'en croirez pas vos yeux</h3>
        <article>
          <h4>06.04.2018 - Les talents du <strong> barista </strong> <span>Barista par ci Barista par là. Mais qui est-ce donc? C'est la personne qui vous accompagnera votre moment de plaisir à déguster votre café. Il est celui vous fascinera dans la façon de preparer <strong>VOTRE café </strong>. Mada coffee shop vous offre ce privilège afin d'explorer le monde <strong>incroyable du café</strong> dans tous ses état. Alors ne ratez surtout pas l'occasion d'assister à ce splendide spéctacle qu'il va vous offrir et qui va vous éblouir. </span></h4>
        </article>
      </section>
    </div>


    
	
    <div class="fourcol">
        <section class="group4">
          
          <h5> >> </h5>
          <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/barista/preparation-cafe-barista-mada-coffe-shop.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/barista/preparation-cafe-barista-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/barista/preparation-cafe-barista-mada-coffe-shop.jpg"); ?>" width="215" height="137" ></a> 
        
       </section>
    </div>

    <div class="fourcol ">
        <section class="group4">
          
          <h5> >> </h5>
          <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/barista/montage-oeuvres-art-cafe-barista-mada-coffe-shop.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/barista/montage-oeuvres-art-cafe-barista-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/barista/montage-oeuvres-art-cafe-barista-mada-coffe-shop.jpg"); ?>" width="215" height="137" ></a> 
        
       </section>
    </div>

    <div class="fourcol last">
      <section class="group4">
        <h5>>></h5>
        <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/accueil/barista/le-latte-art-barista-dessin-cafe-mada-coffe-shop.jpg"); ?>" src="<?php echo base_url("assets/images/accueil/barista/le-latte-art-barista-dessin-cafe-mada-coffe-shop.jpg"); ?>" title="<?php echo base_url("assets/images/accueil/barista/le-latte-art-barista-dessin-cafe-mada-coffe-shop.jpg"); ?>" width="215" height="137"></a> 
        
       </section>
    </div>
    <!--end holder-->
  </div>
</div>



