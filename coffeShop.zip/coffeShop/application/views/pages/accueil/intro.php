<!--start intro-->
<div class="container">
  <div class="row">
    <section id="intro" class="onecol">
      <hgroup>
        <h1>MADA COFFEE SHOP</h1>
        <h2>avez-vous déjà songé à boire votre <strong>café</strong> différement, ne sachant pas lequel ?<strong> Cappuccino, macchiato, latte... </strong> tous des cafés qui ont des ingrédients similaires, mais qui diffèrent quelque peu les uns des autres!  Voici un petit guide qui vous permettra de connaître les <strong> différents types de café</strong> que vous offre Mada coffee shop.  </h2>
      </hgroup>
      <a href="<?php echo site_url("art/listes-oeuvres-barista-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>" class="button1">Oeuvres de notre barista</a> </section>
  </div>
</div>
<!--end intro-->