<!--start intro-->
<div class="container">
  <div class="row">
    <section id="intro" class="onecol">
      <hgroup>
        <h1>COFFEE SHOP</h1>
        <h2>Pour en savoir plus sur les différents types de cafe. La consultation de sa description qui vous renseignera sur les details du café elle-même chez Mada coffee shop. </h2>
      </hgroup>
      <a href="<?php echo site_url("art/listes-oeuvres-barista-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>" class="button1">Oeuvres de notre barista</a> </section>
  </div>
</div>
<!--end intro-->