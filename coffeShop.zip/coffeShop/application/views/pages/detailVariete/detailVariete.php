

<div class="container">
  <div class="row">
    <div class="fourcol">
      <section class="group4">
        <h5><?php echo $variete->nom; ?></h5>
        <a class="photo_hover3" href="#"><img alt="<?php echo base_url("assets/images/variete/". $variete->image); ?>" src="<?php echo base_url("assets/images/variete/". $variete->image); ?>" title="<?php echo base_url("assets/images/variete/". $variete->image); ?>" width="215" height="137" alt=""></a>  </section>
    </div>
	
    <div class="fourcol">
        <section class="group4">
          
          <h5> >> </h5>
          <p><?php echo $variete->description; ?>.</p>
      <a href="#"><span class="button">composant</span></a>
    </div>
   
  </div>
</div>