<? echo "fgerhthrthrgthrhryhr".var_dump($modePaiemenMeretList ); ?>
<div >
<?php  foreach($modePaiemenMeretList as $modePaiemenMere){ ?>
														<tr>
															<td class="center">
																<label class="pos-rel">
																	<input type="checkbox" class="ace" />
																	<span class="lbl"></span>
																</label>
															</td>

															<td>
																<a href="#"><?php echo $result->nom; ?></a>
															</td>
															<td><?php echo $result->prix; ?></td>
															<td ><?php echo $result->description; ?></td>
															<td><?php echo $result->idCategorie; ?> </td>
															<td><?php echo $result->quantiteStock; ?> </td>
															<td><?php echo $result->dateInsertion; ?> </td>
															<td><?php echo $result->image; ?> </td>

														</tr>
													<?php } ?>						
</div>
	
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>





			

			


