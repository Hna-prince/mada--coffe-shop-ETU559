<!--start intro-->
<div class="container">
  <div class="row">
    <section id="intro" class="onecol">
      <hgroup>
        <h1>COFFEE SHOP</h1>
        <h2>Art du cafe. </h2>
      </hgroup>
      <a href="<?php echo site_url("art/listes-oeuvres-barista-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>" class="button1">Oeuvres de notre barista</a> </section>
  </div>
</div>
<!--end intro-->