
<div class="container">
  <div class="row">
    <div class="holder_content1">
      <section class="group4">
        <h3>la gallery d'images du cafe Mada Coffee shop</h3>
        <article>
          <h4>06.04.2018  </a> <span>Qu’il soit corsé, allongé ou encore latte, le <strong>café</strong> se décline à l’infini ! Grâce à notre guide, découvrez ce qui se cache derrière ses différentes appellations pour y voir plus clair au moment de passer commande à <strong>Mada coffee shop</strong>! </span></h4>
        </article>
      </section>
    </div>
    <!--end holder-->
  </div>
</div>

