
<div class="container">
  <div class="row">
    <div class="holder_content1">
      <section class="group4">
        <h3>les specialite du cafe Mada Coffee shop</h3>
        <article>
          <h4>06.04.2018 - <a href="http://www.fraichementpresse.ca/cuisine/differents-types-cafes-1.2276304">Differents type de cafés</a> <span>Qu’il soit corsé, allongé ou encore latte, le <strong>café</strong> se décline à l’infini ! Grâce à notre guide, découvrez ce qui se cache derrière ses différentes appellations pour y voir plus clair au moment de passer commande à <strong>Mada coffee shop</strong>! </span></h4>
        </article>
      </section>
    </div>
    <!--end holder-->
  </div>
</div>

<div class="container">
<div class="row">



  <?php $i=1; foreach($varieteList as $variete){ 
        
        if($i%3!=0){
    ?>
    <div class="fourcol">
<?php   } 
        else{ 
?>
    <div class="fourcol last">

<?php   } ?>
      <section class="group1">
        <h5><?php echo $variete->nom; ?></h5>
        <a class="photo_hover3" href="#"><img src="<?php echo base_url("assets/images/variete/". $variete->image); ?>" width="215" height="137" alt="<?php echo base_url("assets/images/variete/". $variete->nom); ?>" title="<?php echo base_url("assets/images/variete/". $variete->image); ?>"></a> 
        <a href="<?php echo site_url("variete/" . $variete->nom ."-detail-description-cafe-MADA-COFFEE-SHOP-" . $variete->id . "-06042018.html"); ?>"><span class="button"><?php echo $variete->nom; ?> </span></a> </section>
    </div>

<?php $i++; } ?>

</div>
</div>