

<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/styles.css"); ?>">
<link rel="stylesheet" href="<?php echo base_url("assets/css/1140.css"); ?>" type="text/css" media="screen">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="coffe,cafe,mada,shop,moka,latte,barista,boissons,hiver,chaudes,cacao,deguster,degustation,art">
<meta name="Description" content="Site de decouverte des varietes du cafe, Latte, Moka, Americano ... Le gout, l'art : la meilleur facon de profiter votre cafe. Madacoffee shop est un concept franchisé de café, decouvrez de nouveaux saveurs et concepts sur les cafes. Etant Nouveau ou expert dans la degustation des varietes de cafe. Mada Coffe shop va donner du sensation vos papilles, et emerveiller vos yeux, alors preparer vous!">
<!--[if lte IE 9]>
<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<script src="js/html5.js"></script>
<script src="js/css3-mediaqueries.js"></script>
<![endif]-->
