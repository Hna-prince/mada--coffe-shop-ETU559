
<div class="container">
  <div class="row">
    <!--start header-->
    <header>
      <!--start logo-->
      <div class="sixcol"> <a href="#" id="logo"><img src="<?php echo base_url("assets/images/logo.png"); ?>" width="303" height="120" alt=""></a> </div>
      <!--end logo-->
      <!--start menu-->
      <div class="sixcol last">
        <nav>
          <ul>
            <li><a href="<?php echo site_url("accueil-MADA-COFFEE-SHOP-cafe-06042018.html"); ?>">Accueil</a></li>
            <li><a href="<?php echo site_url("variete/listes-differents-specialites-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>">Les specialites</a></li>
            <li><a href="<?php echo site_url("art/listes-oeuvres-barista-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>">Art du cafe</a></li>
			      <li><a href="<?php echo site_url("gallery-cafe-MADA-COFFEE-SHOP-06042018.html"); ?>">Gallery</a></li>
            </ul>
        </nav>
      </div>
      <!--end menu-->
      <img src="<?php echo base_url("assets/images/coffe-shop-picture.png"); ?>" alt="<?php echo base_url("assets/images/coffe-shop-picture.png"); ?>" width="350" height="256"  class="cake">
      <!--end header-->
    </header>
  </div>
</div>

