<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>

<title> <?php $this->load->view($title); 
echo $titleFacultatif;
?></title>
    <?php  
    
        $this->load->view("templates/head");
    ?>
    </head>
    <body>
                         <?php
                             $this->load->view("templates/header");
                             $this->load->view($intro);
                            $this->load->view($contents);
                            $this->load->view("templates/footer");
                        ?>

    </body> 
</html>
