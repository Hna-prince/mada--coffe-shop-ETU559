<footer>
  <div class="container copyright">
    <div class="row">
      <div class="sixcol">
        <div id="FooterTree"> &copy; 2018 </div>
      </div>
      <div class="sixcol last">
        <div id="FooterTwo">Tel 	: <a target="_blank" href="http://www.marijazaric.com">marija zaric</a></div>
        <div id="FooterTwo">Email 	: <a target="_blank" href="http://www.marijazaric.com">marija zaric</a></div>
        <div id="FooterTwo">Adresse : <a target="_blank" href="http://www.marijazaric.com">marija zaric</a></div>
      </div>
    </div>
  </div>
</footer>