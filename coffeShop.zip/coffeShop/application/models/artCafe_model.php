<?php
    class ArtCafe_model extends MY_Model{
        protected $table='artCafe';
        protected $predicat='ART';

        private $id;
        private $intitule;
        private $image;

        public function __construct() {
            parent::__construct();
         }

        public function initSelect($id,$intitule, $image){
            $this->setId( $id);
            $this->setintitule( $intitule);
            $this->setimage($image);
           
        }
        public function initInsert($intitule, $image){
            $this->setId( $this->getIdInsert());
            $this->setintitule( $intitule);
            $this->setimage($image);
           
        }

        
        
        public function getDonneesEchappees(){

            $data['id']            =$this->getId();
            $data['intitule']           =$this->getintitule();
            $data['image']         =$this->getimage();

            return $data;
        }
        public function getDonneesNonEchappees(){
            return array();
        }
        

        public function getId(){
            return  $this->id;
        }
        public function setId($id){
            $this->id=$id;
        }

        public function getintitule(){
            return  $this->intitule;
        }
        public function setintitule($intitule){
            $this->intitule=$intitule;
        }
         public function getimage(){
            return  $this->image;
        }
        public function setimage($image){
            $this->image=$image;
        }


        

        
    }
?>