<?php
    class Devis_model extends MY_Model{
        protected $table='variete';
        protected $predicat='VAR';

        private $id;
        private $idClient;
        private $idDestination;
        private $dateDevis;
        private $dateDebut;
        private $dateFin;
        private $status;

        public function __construct() {
            parent::__construct();
         }

        public function initSelect($id,$idclient, $idDestination,$dateDevis,$dateDebut, $dateFin,$status){
            $this->setId( $id);
            $this->setIdClient( $idclient);
            $this->setIdDestination( $idDestination);
            $this->setDateDevis( $dateDevis);
            $this->setDateDebut( $dateDebut);
            $this->setDateFin($dateFin);
            $this->setStatus($status);
           
        }
        public function initInsert($idclient, $idDestination,$dateDevis,$dateDebut, $dateFin,$status){
            $this->setId( $this->getIdInsert());
            $this->setIdClient( $idclient);
            $this->setIdDestination( $idDestination);
            $this->setDateDevis( $dateDevis);
            $this->setDateDebut( $dateDebut);
            $this->setDateFin($dateFin);
            $this->setStatus($status);
           
        }

        
        
        public function getDonneesEchappees(){

            $data['id']            =$this->getId();
            $data['idClient']      =$this->getIdClient();
            $data['idDestination'] =$this->getIdDestination();
            $data['dateDebut']     =$this->getDateDebut();
            $data['dateFin']       =$this->getDateFin();
            $data['status']        =$this->getStatus();

            return $data;
        }
        public function getDonneesNonEchappees(){
            $data['dateDevis']='NOW()';
            return $data;
        }
        

        public function getId(){
            return  $this->id;
        }
        public function setId($id){
            $this->id=$id;
        }

        public function getIdClient(){
            return  $this->idClient;
        }
        public function setIdClient($idClient){
            $this->idClient=$idClient;
        }
        public function getIdDestination(){
            return  $this->idDestination;
         }
          public function setIdDestination($idDestination){
            $this->idDestination=$idDestination;
         }

         public function getDateDevis(){
            return  $this->dateDevis;
         }
          public function setDateDevis($dateDevis){
            $this->dateDevis=$dateDevis;
         }

         public function getDateDebut(){
            return  $this->dateDebut;
         }
          public function setDateDebut($dateDebut){
            $this->dateDebut=$dateDebut;
         }
         public function getDateFin(){
            return  $this->dateFin;
        }
        public function setDateFin($dateFin){
            $this->dateFin=$dateFin;
        }


        public function getStatus(){
            return  $this->status;
         }
          public function setStatus($status){
            $this->status=$status;
         }

        
    }
?>