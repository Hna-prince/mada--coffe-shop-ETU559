<?php
    class Variete_model extends MY_Model{
        protected $table='variete';
        protected $predicat='VAR';

        private $id;
        private $nom;
        private $description;
        private $idCategorie;
        private $image;

        public function __construct() {
            parent::__construct();
         }

        public function initSelect($id,$nom, $description,$idCategorie, $image){
            $this->setId( $id);
            $this->setnom( $nom);
            $this->setdescription( $description);
            $this->setidCategorie( $idCategorie);
            $this->setimage($image);
           
        }
        public function initInsert($nom, $description,$idCategorie, $image){
            $this->setId( $this->getIdInsert());
            $this->setnom( $nom);
            $this->setdescription( $description);
            $this->setidCategorie( $idCategorie);
            $this->setimage($image);
           
        }

        
        
        public function getDonneesEchappees(){

            $data['id']            =$this->getId();
            $data['nom']           =$this->getnom();
            $data['description']   =$this->getdescription();
            $data['idCategorie']   =$this->getidCategorie();
            $data['image']         =$this->getimage();

            return $data;
        }
        public function getDonneesNonEchappees(){
            return $data;
        }
        

        public function getId(){
            return  $this->id;
        }
        public function setId($id){
            $this->id=$id;
        }

        public function getnom(){
            return  $this->nom;
        }
        public function setnom($nom){
            $this->nom=$nom;
        }
        public function getdescription(){
            return  $this->description;
         }
          public function setdescription($description){
            $this->description=$description;
         }

        
         public function getidCategorie(){
            return  $this->idCategorie;
         }
          public function setidCategorie($idCategorie){
            $this->idCategorie=$idCategorie;
         }
         public function getimage(){
            return  $this->image;
        }
        public function setimage($image){
            $this->image=$image;
        }


        

        
    }
?>