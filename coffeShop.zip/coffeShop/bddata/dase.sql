create database locationvaiselle;
use locationvaiselle;
create table idTable (
	predicat varchar(3),
	currentValue int
);

create table administrateur(
	id varchar(7) primary key,
	email varchar(20),
	nom  varchar(15),
	password varchar(20)
)ENGINE = InnoDB;

create table categorie(
    id varchar(7) primary key,
    nom  varchar(15),
    idCategorieMere varchar(7)
)ENGINE = InnoDB;

create table article(
    id varchar(7) primary key,
    nom  varchar(70),
	prix double,
    description varchar(80),
    idCategorie varchar(7),
	quantiteStock int,
	dateInsertion datetime,
	image varchar(60),
    foreign key (idCategorie) references categorie(id)
)ENGINE = InnoDB;
/*create table prix(
    idArticle varchar(7),
    prix decimal,
    foreign key idArticle references article(id)
)ENGINE = InnoDB;*/

create table historiquePrix(
    id varchar(7) primary key,
    idArticle varchar(7),
    prix double,
	dateEnregistrement datetime,
    foreign key (idArticle) references article(id)
)ENGINE = InnoDB;

create table configurationtva(
    pourcentage double
)ENGINE = InnoDB;

create table historiqueConfigurationtva(
	id varchar(7) primary key,
	dateConf date,
    pourcentage double
)ENGINE = InnoDB;


create table CLIENT (
   id            		VARCHAR(7)     primary key,
   NOM                  VARCHAR(20)          ,
   PRENOM               VARCHAR(30)          ,
   email	VARCHAR(30),
   MOTDEPASSE           VARCHAR(20)          ,
   titre	int			,
   profil   VARCHAR(60)
)ENGINE = InnoDB;
/*0: msr; 1:mme; 2:mmlle: 3:inconnu*/
create table panier(
    id varchar(7) primary key,
    iClient varchar(7),
	dateEnregistrement datetime,
	listArticle varchar(78),
	listQuantite varchar(18),
    foreign key (iClient) references CLIENT(id)
)ENGINE = InnoDB;

create table pays(
    id varchar(7) primary key,
	nomPays varchar(20)
)ENGINE = InnoDB;

create table DESTINATIONLIVRAISON (
   ID        VARCHAR(7)           primary key,
   IDPAYS               VARCHAR(7)           not null,
   ADRESSE1              VARCHAR(30)          ,
   ADRESSE2             VARCHAR(30)          ,
   codePostal             VARCHAR(7)          ,
   VILLE                VARCHAR(30)          ,
   phone			VARCHAR(15)          ,
   
    foreign key (IDPAYS) references pays(id)
)ENGINE = InnoDB;

create table DEVIS (
   ID			         VARCHAR(7)           primary key,
   idClient				VARCHAR(7) ,
   IDDESTINATION        VARCHAR(7)          ,
   DATEDEVIS            DATE                 ,
   DATEDEBUT            DATE                 ,
   DATEFIN              DATE                 ,
   STATUS               int         ,

    foreign key (IDDESTINATION) references DESTINATIONLIVRAISON(id)   ,
    foreign key (idClient) references client(id)   
)ENGINE = InnoDB;

create table DETAILDEVIS (
   ID			        VARCHAR(7)           primary key,
   IDDEVIS              VARCHAR(7)           not null,
   idArticle            VARCHAR(7)           not null,
   QUANTITEDEMANDE      double                 ,
   
    foreign key (IDDEVIS) references DEVIS(id),
    foreign key (idArticle) references article(id)
)ENGINE = InnoDB;

/*create table facture (
   ID			         VARCHAR(7)           primary key,
   IDDEVIS        VARCHAR(7)          ,
   montantTTC     	double,
   montantTva		double,
   remise			double,
   dateFacture		DATE,

    foreign key (IDDEVIS) references devis(id)   
)ENGINE = InnoDB;*/

create table facture (
   ID			         VARCHAR(7)           primary key,
   IDDEVIS        VARCHAR(7)          ,
   montantTTC     	double,
   montantTva		double,
   remise			double,
   dateFacture		DATE,
   rap				double,

    foreign key (IDDEVIS) references devis(id)   
)ENGINE = InnoDB;

CREATE TABLE modePaiement(
	ID			         VARCHAR(7) primary key,
	indexation			VARCHAR(1),
	nom					VARCHAR(30),
	modePaiementMere	VARCHAR(20)
);

CREATE TABLE paiement(
	ID			   	VARCHAR(7) primary key,
	datePaiement 	DATE,
	idFacture 		VARCHAR(7),
	montant 		double,
	modePaiement	VARCHAR(7),
	FOREIGN KEY(idFacture) REFERENCES facture(ID)
);

create view articleFacture as (select dtD.idDevis,a.id,a.nom,a.prix,dtD.QUANTITEDEMANDE from detailDevis dtD join article a where dtD.idArticle=a.id);

insert into idTable values('CAT',1);
insert into idTable values('ART',1);
insert into idTable values('HTP',1);
insert into idTable values('ADM',1);
insert into idTable values('CLT',1);
insert into idTable values('PNR',1);
insert into idTable values('PAY',1);
insert into idTable values('DTL',1);
insert into idTable values('DEV',1);
insert into idTable values('DDV',1);
insert into idTable values('FAC',1);
insert into idTable values('MPY',1);
insert into idTable values('PMT',1);


insert into administrateur values('ADM0','hna@gmail.com','hna','hna');

/*insert into categorie values('CAT','vaisselle et Art de la table',null);
insert into categorie values('CAT',' mobilier',null);
insert into categorie values('CAT',' buffets et bars','');
insert into categorie values('CAT','matériel et accessoires de cuisine',null);
insert into categorie values('CAT','nappages et juponnages',null);
insert into categorie values('CAT','decoration',null);*/

insert into categorie values('CAT1','Assiette',null);
insert into categorie values('CAT2','Verre',null);

insert into categorie values('CAT3','Creuse','CAT1');
insert into categorie values('CAT4','plate','CAT1');
insert into categorie values('CAT5','Verre à pied','CAT2');
insert into categorie values('CAT6','Verre long','CAT2');

insert into categorie values('CAT','','');

insert into article values('ART1','Assiette creuse Europa 22 cm bruno Evard',2000,'Assiette creuse blanche de 22 cm de diamètre.','CAT3',5,'2017-01-01','assiette/creuse/brunoEvard.jpg');
insert into article values('ART2','Assiette de présentation Europa 30 cm terre d\'Origine',3500,'Assiette pe présentation blanche de 30 cm de diamètre.','CAT4',4,'2017-02-02','assiette/creuse/terreOrigine.jpg');
insert into article values('ART3','Assiette plate royal doulton pacific lines',2200,'Assiette plate beige de 20 cm de diamètre.','CAT4',6,'2017-03-03','assiette/plate/royaldoulton.jpg');
insert into article values('ART4','Assiette plate palette light blue 27 cm',3000,'Assiette plate grise de 27 cm de diamètre.','CAT4',3,'2017-04-04','assiette/plate/lightblue.jpg');
insert into article values('ART5','Coupe à champagne 13 cl',2500,'Coupe à champagne 13 cl en cristal','CAT5',7,'2017-05-05','verre/pied/champagne.jpg');
insert into article values('ART6','Verre à morito 15 cl',2000,'Verre à morito 15 cl en verre sombre','CAT6',8,'2017-06-06','verre/long/morito.jpg');
insert into article values('ART7','Verre long drink 27 cl Tumbler',4000,'Verre long drink de 27 cl','CAT6',10,'2017-07-07','verre/long/drink.jpg');
insert into article values('ART8','Verre viticole Inao 25 cl',4000,'Verre viticole de 25 cl','CAT5',2,'2017-08-08','verre/pied/viticole.jpg');

insert into article values('ART','',,'','',,'','');

insert into historiquePrix values('HTP1','ART1',2000,'2017-01-01');
insert into historiquePrix values('HTP2','ART2',3500,'2017-02-02');
insert into historiquePrix values('HTP3','ART3',2200,'2017-03-03');
insert into historiquePrix values('HTP4','ART4',3000,'2017-04-04');
insert into historiquePrix values('HTP5','ART5',2500,'2017-05-05');
insert into historiquePrix values('HTP6','ART6',2000,'2017-06-06');
insert into historiquePrix values('HTP7','ART7',4000,'2017-07-07');
insert into historiquePrix values('HTP8','ART8',4000,'2017-08-08');
insert into historiquePrix values('HTP','ART',,'');

insert into configurationtva values(20);

insert into pays values('PAY1','Madagascar');
insert into pays values('PAY2','Etats-Unis');
insert into pays values('PAY3','France');
insert into pays values('PAY4','Japon');
insert into pays values('PAY','');

insert into client values('CLT1','1');

insert into client values('CLT2','max','max','max@gmail.com','max',0,'default.jpg');


insert into modePaiement values('MPY1','1','virement','0');
insert into modePaiement values('MPY2','2','Cheque','0');
insert into modePaiement values('MPY3','3','Mobile','0');
insert into modePaiement values('MPY4','4','Espece','0');

insert into modePaiement values('MPY5','1','BOA','MPY1;MPY2');
insert into modePaiement values('MPY6','2','BNI','MPY1;MPY2');
insert into modePaiement values('MPY7','3','BFV','MPY1;MPY2');
insert into modePaiement values('MPY8','4','AirtelMoney','MPY3');
insert into modePaiement values('MPY9','5','MVola','MPY3');

insert into modePaiement values('MPY',,'','');
insert into modePaiement values('MPY',,'','');

create view factureDetail as( select * from facture f join devis d on f.idDevis=d.ID);

insert into facture values ('FAC1','',,,,'',);