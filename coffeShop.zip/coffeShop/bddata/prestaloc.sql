CREATE DATABASE prestaloc;

CREATE TABLE client(
	idclient serial NOT NULL,
	nom VARCHAR(30),
	prenom VARCHAR(30),
	email VARCHAR(50),
    mdp VARCHAR(150),
	PRIMARY KEY (idclient)
);

CREATE TABLE categorie(
	idcategorie serial NOT NULL,
	nomcategorie VARCHAR(30),
	idcategoriemere INTEGER,
	PRIMARY KEY (idcategorie),
	FOREIGN KEY(idcategoriemere) REFERENCES categorie(idcategorie)
);

CREATE TABLE produit(
	idproduit serial NOT NULL,
	idcategorie INTEGER,
	nomproduit VARCHAR(50),
	puj INTEGER,
	quantitestock INTEGER,
	description VARCHAR(200),
	PRIMARY KEY (idproduit),
	FOREIGN KEY(idcategorie) REFERENCES categorie(idcategorie)
);

CREATE TABLE paniermere(
	idpaniermere serial NOT NULL,
	idclient INTEGER,
	datepanier DATE,
	debutlocation DATE,
	finlocation DATE,
	PRIMARY KEY (idpaniermere),
	FOREIGN KEY(idclient) REFERENCES client(idclient)
);

CREATE TABLE panierfille(
	idpanierfille serial NOT NULL,
	idpaniermere INTEGER,
	idproduit INTEGER,
	quantite INTEGER,
	PRIMARY KEY (idpanierfille),
	FOREIGN KEY(idpaniermere) REFERENCES paniermere(idpaniermere),
	FOREIGN KEY(idproduit) REFERENCES produit(idproduit)
);

CREATE TABLE facturemere(
	idfacturemere serial NOT NULL,
	idclient INTEGER,
	idpaniermere INTEGER,
	datefacture DATE,
	montantht INTEGER,
	montanthtremise INTEGER,
	montantttc INTEGER,
	PRIMARY KEY (idfacturemere),
	FOREIGN KEY(idpaniermere) REFERENCES paniermere(idpaniermere),
	FOREIGN KEY(idclient) REFERENCES client(idclient)
);

CREATE TABLE facturefille(
	idfacturefille serial NOT NULL,
	idfacturemere INTEGER,
	idpanierfille INTEGER,
	montantht INTEGER,
	montanthtremise INTEGER,
	montantttc INTEGER,
	PRIMARY KEY (idfacturefille),
	FOREIGN KEY(idfacturemere) REFERENCES facturemere(idfacturemere),
	FOREIGN KEY(idpanierfille) REFERENCES panierfille(idpanierfille)
);

CREATE TABLE location(
	idlocation serial NOT NULL,
	idfacturemere INTEGER,
	debutlocation DATE,
	finlocation DATE,
	PRIMARY KEY (idlocation),
	FOREIGN KEY(idfacturemere) REFERENCES facturemere(idfacturemere)
);

CREATE TABLE tva(
	idtva serial NOT NULL,
	datechangement DATE,
	taux INTEGER,
	PRIMARY KEY (idtva)
);

CREATE TABLE remise(
	idremise serial NOT NULL,
	idproduit INTEGER,
	taux INTEGER,
	debutremise DATE,
	finremise DATE,
	PRIMARY KEY (idremise),
	FOREIGN KEY(idproduit) REFERENCES produit(idproduit)
);

CREATE TABLE paiement(
	idpaiement serial NOT NULL,
	idfacturemere INTEGER,
	datepaiement DATE,
	montant INTEGER,
	PRIMARY KEY (idpaiement),
	FOREIGN KEY(idfacturemere) REFERENCES facturemere(idfacturemere)
);

INSERT INTO client(nom, prenom, email, mdp) VALUES('Admin', 'Boss', 'admin@mail.com', 'root');  
INSERT INTO client(nom, prenom, email, mdp) VALUES('Rak', 'Tefy', 'tefy@mail.com', '1234');  

INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Root', 1);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Assiette', 1);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Verre', 1);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Creuse', 2);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Plate', 2);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Verre à pied', 3);
INSERT INTO categorie(nomcategorie, idcategoriemere) VALUES('Verre long', 3);

INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(2, 'Assiette creuse Europa 22 cm', 2000, 200, 'Assiette creuse blanche de 22 cm de diamètre.');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(2, 'Assiette de présentation Europa 30 cm', 3500, 150, 'Assiette pe présentation blanche de 30 cm de diamètre.');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(2, 'Assiette plate Europa 20 cm', 2200, 200, 'Assiette plate beige de 20 cm de diamètre.');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(2, 'Assiette plate Europa 27 cm', 3000, 175, 'Assiette plate grise de 27 cm de diamètre.');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(3, 'Coupe à champagne 13 cl', 2500, 350, 'Coupe à champagne 13 cl en cristal');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(3, 'Verre à morito 15 cl', 2000, 400, 'Verre à morito 15 cl en verre sombre');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(3, 'Verre long drink 27 cl Tumbler', 4000, 200, 'Verre long drink de 27 cl');
INSERT INTO produit(idcategorie, nomproduit, puj, quantitestock, description) VALUES(3, 'Verre viticole Inao 25 cl', 4000, 200, 'Verre viticole de 25 cl');
