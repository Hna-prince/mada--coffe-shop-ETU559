
angular.module('appBinding', []).controller('appBindingCtrl', function($scope,$http) {
    
            $scope.showSubCategoryCorresponding = function (baseUrl) {
                $scope.SubModePaiementList;

                 var url=baseUrl+"webService/getSubCategory/"+$scope.idCategorieMere;
                    if($scope.idCategorieMere!=""){
                        $http.get(url).then(function (response) {
                            $scope.SubModePaiementList = response.data;
                            //document.getElementById("sousCategorieList").innerHTML=response.data[0].id;
                            
                            //console.log(response.data+"ccacacacacacacac");
                            //console.log($scope.SubModePaiementList.length+"mimifmsfrg");
                            if(response.data!=null){
                                var select="<label for=\"form-field-select-1\">Sous Categorie</label> <div class=\"col-sm-9\"> <select class=\"form-control\"  name=\"idSousCategorie\" id=\"form-field-select-1\"> <option value=\"\">Tous</option>";
                                for(var i=0; i < $scope.SubModePaiementList.length; i++){
                                    select+="<option value=\""+$scope.SubModePaiementList[i].id+"\">"+$scope.SubModePaiementList[i].nom+"</option>";
                                    
                                }
                                select+="</select> </div>";
                                document.getElementById("sousCategorieList").innerHTML=select;
                            }
                            else{
                                document.getElementById("sousCategorieList").innerHTML="  ";
                            }
                        });
                    }
                    else{
                        document.getElementById("sousCategorieList").innerHTML="  ";
                    }
            };
            

        });



angular.module('appBindingMPmt', []).controller('appBindingMPmtCtrl', function($scope,$http) {
            
                    $scope.showSubCategoryCorresponding = function (baseUrl) {
                        $scope.SubModePaiementList;
        
                         var url=baseUrl+"webService/getSubModePaiement/"+$scope.idCategorieMere;
                            if($scope.idModePaiementMere!=""){
                                $http.get(url).then(function (response) {
                                    $scope.SubModePaiementList = response.data;
                                    //document.getElementById("sousCategorieList").innerHTML=response.data[0].id;
                                    
                                    //console.log(response.data+"ccacacacacacacac");
                                    //console.log($scope.SubModePaiementList.length+"mimifmsfrg");
                                    if(response.data!=null){
                                        var select="<label for=\"form-field-select-1\">Sous Categorie mode de paiement</label> <div class=\"col-sm-9\"> <select class=\"form-control\"  name=\"idModePaiementFils\" id=\"form-field-select-1\"> <option value=\"\">Tous</option>";
                                        for(var i=0; i < $scope.SubModePaiementList.length; i++){
                                            select+="<option value=\""+$scope.SubModePaiementList[i].id+"\">"+$scope.SubModePaiementList[i].nom+"</option>";
                                            
                                        }
                                        select+="</select> </div>";
                                        document.getElementById("modePaiementFilsList").innerHTML=select;
                                    }
                                    else{
                                        document.getElementById("modePaiementFilsList").innerHTML="  ";
                                    }
                                });
                            }
                            else{
                                document.getElementById("modePaiementFilsList").innerHTML="  ";
                            }
                    };
                    
        
                });
        