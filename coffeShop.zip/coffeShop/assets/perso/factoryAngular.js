"<label for=\"form-field-select-1\">Sous Categorie</label> <div class=\"col-sm-9\"> <select class=\"form-control\"  name=\"idSousCategorie\" id=\"form-field-select-1\"><option value=\"\"></option>
																<option value=\"AL\">Alabama</option>
															</select>
										</div>"